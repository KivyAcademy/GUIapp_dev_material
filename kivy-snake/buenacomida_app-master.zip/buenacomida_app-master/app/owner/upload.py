from kivy.uix.screenmanager import Screen

from kivyrt.paths import load_kv


class LocationForm(FormBehavior, Screen):
    pass

