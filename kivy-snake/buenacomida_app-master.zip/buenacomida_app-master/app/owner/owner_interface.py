
def search(restaurant):
    return ' '.join((restaurant['search_name'], restaurant['address'].lower()))

