python main.py -m screen:phone_iphone_6,portrait,scale=.7
